import DefaultTheme from 'vitepress/theme'
import './style.css' // 导入你的自定义 CSS 文件

export default DefaultTheme 